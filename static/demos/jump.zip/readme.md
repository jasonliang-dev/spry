## Assets

- `atlas.png` https://www.kenney.nl/assets/pixel-platformer (CC0)
- `phaserUp1.ogg`, `phaseJump2.ogg` https://www.kenney.nl/assets/digital-audio (CC0)
- `king-around-here.ogg` https://pixabay.com/music/beats-electronic-rock-king-around-here-15045/ (https://pixabay.com/service/license-summary/)